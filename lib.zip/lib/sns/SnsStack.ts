import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';
import {SNS} from "../config";


class SnsStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super();

        // create sns topic and add email subscription to it
        const topic = new cdk.aws_sns.Topic(this, SNS.TOPIC_NAME, {
            displayName: SNS.DISPLAY_NAME,
            topicName: SNS.TOPIC_NAME
        })

        SNS.EMAIL.forEach(email => {
            topic.addSubscription(new cdk.aws_sns_subscriptions.EmailSubscription(email))
        })
    }
}