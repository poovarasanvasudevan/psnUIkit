import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';
import {ACCOUNT_ID, REGION, SNS} from "../config";

class LambdaStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props);

        //create python lambda function and add sns permission to it
        const lambda = new cdk.aws_lambda.Function(this, "pmp-lambda", {
            runtime: cdk.aws_lambda.Runtime.PYTHON_3_8,
            handler: "lambda_function.lambda_handler",
            code: cdk.aws_lambda.Code.fromAsset("lambda"),
            timeout: cdk.Duration.seconds(300),
            memorySize: 1024,
        })

        lambda.addToRolePolicy(new cdk.aws_iam.PolicyStatement({
            effect: cdk.aws_iam.Effect.ALLOW,
            actions: ["sns:Publish"],
            resources: [`arn:aws:sns:${REGION}:${ACCOUNT_ID}:${SNS.TOPIC_NAME}`],
        }))

    }
}