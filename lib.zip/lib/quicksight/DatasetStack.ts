import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';

class DatasetStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props);



        //create quicksight dataset with athena query
        const dataset = new cdk.aws_quicksight.CfnDataSet(this, "pmp-dataset", {
            awsAccountId: "123456789012",
            dataSetId: "pmp-dataset",
            name: "pmp-dataset",
            importMode: "DIRECT_QUERY",

            physicalTableMap: {
                "pmp-dataset": {
                    customSql: {
                        dataSourceArn: "arn:aws:athena:us-east-1:123456789012:workgroup/primary",
                        name: "pmp-dataset",
                        sqlQuery: "SELECT * FROM pmp.pmp_",
                        columns: [
                            {
                                name: "id",
                                type: "INTEGER",
                            },
                        ],
                    },
                }
            },

            logicalTableMap: {
                "pmp-dataset": {
                    alias: "pmp-dataset",
                    source: {
                        physicalTableId: "pmp-dataset"
                    }
                }
            }
        })


    }
}