import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';

class AnalysisStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super();
        const analysis = new cdk.aws_quicksight.CfnAnalysis(this, "pmp-analysis", {
            awsAccountId: "123456789012",
            analysisId: "pmp-analysis",
            name: "pmp-analysis",
            permissions: [
                {
                    actions: [
                        "quicksight:DescribeAnalysis",
                        "quicksight:DescribeDashboard",
                        "quicksight:DescribeDataSet",
                        "quicksight:DescribeDataSource",
                        "quicksight:DescribeTemplate",
                        "quicksight:DescribeTheme",
                        "quicksight:DescribeUser",
                        "quicksight:ListAnalyses",
                        "quicksight:ListDashboards",
                    ],
                    principal: "arn:aws:quicksight:us-east-1:123456789012:user/default/123456789012",
                }
            ],
            sourceEntity: {
                sourceTemplate: {
                    arn: "arn:aws:quicksight:us-east-1:123456789012:template/pmp-template",
                    dataSetReferences: [
                        {
                            dataSetPlaceholder: "pmp-dataset",
                            dataSetArn: "arn:aws:quicksight:us-east-1:123456789012:data-set/pmp-dataset",
                        },
                        {
                            dataSetPlaceholder: "pmp-dataset",
                            dataSetArn: "arn:aws:quicksight:us-east-1:123456789012:data-set/pmp-dataset",
                        }
                    ]
                }
            },
            themeArn: "arn:aws:quicksight:us-east-1:123456789012:theme/pmp-theme",
        })


        const template = new cdk.aws_quicksight.CfnTemplate(this, "pmp-template", {
            awsAccountId: "123456789012",
            templateId: "pmp-template",
            name: "pmp-template",
            versionDescription: "pmp-template",
            sourceEntity: {
                sourceAnalysis: {
                    arn: "arn:aws:quicksight:us-east-1:123456789012:analysis/pmp-analysis",
                    dataSetReferences: [
                        {
                            dataSetPlaceholder: "pmp-dataset",
                            dataSetArn: "arn:aws:quicksight:us-east-1:123456789012:data-set/pmp-dataset",
                        },
                        {
                            dataSetPlaceholder: "pmp-dataset",
                            dataSetArn: "arn:aws:quicksight:us-east-1:123456789012:data-set/pmp-dataset",
                        }
                    ]
                }
            },
            permissions: [],
            //resourcePermission: [],
            tags: [],
            //templateType: "QUICKSIGHT",
            //versionNumber: 1,
        })

    }
}
