import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';

class CloudwatchStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props);

        // create dashboard
        const dashboard = new cdk.aws_cloudwatch.Dashboard(this, "pmp-dashboard", {
            dashboardName: "pmp-dashboard"
        })

        dashboard.addWidgets(
            new cdk.aws_cloudwatch.GraphWidget({
                title: "pmp-dashboard",
                left: [
                    new cdk.aws_cloudwatch.Metric({
                        metricName: "FailedIngestions",
                        namespace: "AWS/QuickSight",
                        statistic: "Sum",
                        period: cdk.Duration.minutes(1),
                        unit: cdk.aws_cloudwatch.Unit.COUNT
                    }),
                ],
                width: 24,
                height: 6,
                leftYAxis: {
                    showUnits: false
                }
            }
        ))

        //create cloudwatch dashboard for crawler failed
        dashboard.addWidgets(
            new cdk.aws_cloudwatch.GraphWidget({
                title: "pmp-dashboard",
                left: [
                    new cdk.aws_cloudwatch.Metric({
                        metricName: "FailedCrawls",
                        namespace: "AWS/Glue",
                        statistic: "Sum",
                        period: cdk.Duration.minutes(1),
                        unit: cdk.aws_cloudwatch.Unit.COUNT
                    }),
                ],
                width: 24,
                height: 6,
                leftYAxis: {
                    showUnits: false

                }
            })
        )
    }
}