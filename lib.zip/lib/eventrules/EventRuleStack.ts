import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';

class EventRuleStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props);



        // create event rule if glue crawler failed
        const rule = new cdk.aws_events.Rule(this, "pmp-event-rule", {
            eventPattern: {
                source: ["aws.glue"],
                detailType: ["Glue Crawler State Change"],
                detail: {
                    state: ["FAILED"],
                    crawlerName: ["s3-crawler"]
                }
            },
            description: "Call lambda if crawler failed to run",
            enabled: true,
            ruleName: "pmp-event-rule"
        })
        rule.addTarget(
            new cdk.aws_events_targets.LambdaFunction(
                new cdk.aws_lambda.Function(this, "pmp-lambda", {
                    runtime: cdk.aws_lambda.Runtime.NODEJS_12_X,
                    handler: "index.handler",
                    code: cdk.aws_lambda.Code.fromAsset("lambda"),
                    timeout: cdk.Duration.seconds(300),
                    memorySize: 1024,
                })
            )
        )
    }
}