import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';
import {ManagedPolicy} from "aws-cdk-lib/aws-iam";


export class CrawlerStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props);

        const policy = "arn:aws:iam::aws:policy/AmazonS3FullAccess";

        const glueCrawlerRole = new cdk.aws_iam.Role(
            this,
            "GlueCrawlerRole", {
                roleName: "AWSGlueServiceRole-AccessingS3Bucket",
                managedPolicies: [
                    ManagedPolicy.fromManagedPolicyArn(
                        this,
                        "glue-service-policy",
                        policy
                    )
                ],
                assumedBy: new cdk.aws_iam.ServicePrincipal("glue.amazonaws.com")
            }
        )

        // create athena database
        const db = new cdk.aws_athena.CfnDataCatalog(this, "pmp-database", {
            name: "pmp",
            type: "GLUE"
        })


        const crawler = new cdk.aws_glue.CfnCrawler(this, "pmp-crawler", {
            name: "s3-crawler",
            role: glueCrawlerRole.roleName,
            targets: {
                s3Targets: [
                    {path: "s3://pmp-raw-data/"},
                    {path: "s3://pmp-raw-data/"},
                    {path: "s3://pmp-raw-data/"},
                    {path: "s3://pmp-raw-data/"},
                ]
            },
            databaseName: "pmp",
            tablePrefix: "pmp_",
            schemaChangePolicy: {
                updateBehavior: "UPDATE_IN_DATABASE",
                deleteBehavior: "DEPRECATE_IN_DATABASE"
            }
        })

    }


}