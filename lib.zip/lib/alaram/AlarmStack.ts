import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';


export class CdkdemoStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props);


        //create alaram if quicksight dataset ingestion fails
        // @ts-ignore
        const alarm = new cdk.aws_cloudwatch.Alarm(this, "pmp-alarm", {
            alarmName: "pmp-alarm",
            metric: new cdk.aws_cloudwatch.Metric({
                metricName: "FailedIngestions",
                namespace: "AWS/QuickSight",
                statistic: "Sum",
                period: cdk.Duration.minutes(1),
                unit: cdk.aws_cloudwatch.Unit.COUNT,

            }),
            threshold: 0,
            evaluationPeriods: 1,
            comparisonOperator: cdk.aws_cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            treatMissingData: cdk.aws_cloudwatch.TreatMissingData.NOT_BREACHING,
            actionsEnabled: true,
            alarmDescription: "pmp-alarm"
        })

        //create alaram if crawler failed to run
        // @ts-ignore
        const alarm2 = new cdk.aws_cloudwatch.Alarm(this, "pmp-alarm2", {
            alarmName: "pmp-alarm2",
            metric: new cdk.aws_cloudwatch.Metric({
                metricName: "FailedCrawls",
                namespace: "AWS/Glue",
                statistic: "Sum",
                period: cdk.Duration.minutes(1),
                unit: cdk.aws_cloudwatch.Unit.COUNT,
            }),
        })
    }
}