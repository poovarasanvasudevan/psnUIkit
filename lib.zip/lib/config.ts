export const ACCOUNT_ID = "123456789012";
export const REGION = "us-east-1";


export const SNS = {
    "TOPIC_NAME": "pmp-sns-topic",
    "DISPLAY_NAME": "pmp-sns-topic",
    "EMAIL": [
        ""
    ]
}
